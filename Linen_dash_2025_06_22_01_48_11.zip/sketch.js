// Jogo "Do Campo à Cidade" - Versão Difícil Funcional
let caminhao;
let alimentos = [];
let obstaculos = [];
let pontuacao = 0;
let faseAtual = 1;
let maxFases = 5;
let velocidade = 3;
let gameState = "instrucoes";
let timerAlimentos = [];

function setup() {
  createCanvas(800, 400);
  caminhao = new Caminhao();
  
  for (let i = 0; i < 3; i++) {
    alimentos.push(new Alimento(random(width/2), height - 50));
    timerAlimentos.push(floor(random(300, 500)));
  }
}

function draw() {
  if (gameState === "instrucoes") {
    telaInstrucoes();
    return;
  }
  
  if (gameState === "jogando") {
    jogoRodando();
  } else if (gameState === "gameover") {
    telaGameOver();
  } else if (gameState === "vitoria") {
    telaVitoria();
  }
}

function telaInstrucoes() {
  background(144, 238, 144);
  fill(0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("DO CAMPO À CIDADE - MODO DIFÍCIL", width/2, 60);
  
  textSize(20);
  text("Instruções:", width/2, 120);
  text("- Setas para mover (caminhão mais lento)", width/2, 160);
  text("- ESPAÇO para coletar alimentos (desaparecem rápido!)", width/2, 190);
  text("- Leve alimentos para a cidade (lado direito)", width/2, 220);
  text("- Muitos obstáculos em todas as alturas", width/2, 250);
  text("- 100 pontos por fase (5 fases totais)", width/2, 280);
  text("- Cuidado com obstáculos voadores!", width/2, 310);
  
  fill(200, 0, 0);
  rect(width/2 - 100, 350, 200, 50, 10);
  fill(255);
  text("Clique para começar", width/2, 375);
}

function jogoRodando() {
  background(144, 238, 144);
  fill(169, 169, 169);
  rect(width/2, 0, width/2, height);
  stroke(0);
  line(width/2, 0, width/2, height);
  
  caminhao.update();
  caminhao.display();
  
  // Alimentos
  for (let i = alimentos.length - 1; i >= 0; i--) {
    alimentos[i].update();
    alimentos[i].display();
    
    if (!alimentos[i].coletado) {
      timerAlimentos[i]--;
      if (timerAlimentos[i] <= 0) {
        alimentos.splice(i, 1);
        timerAlimentos.splice(i, 1);
        continue;
      }
      
      if (timerAlimentos[i] < 100 && frameCount % 20 < 10) {
        alimentos[i].display(true);
      }
    }
    
    if (alimentos[i].coletado && !alimentos[i].entregue) {
      alimentos[i].x = caminhao.x;
      alimentos[i].y = caminhao.y - 20;
    }
    
    if (alimentos[i].x > width/2 && alimentos[i].coletado && !alimentos[i].entregue) {
      alimentos[i].entregue = true;
      pontuacao += 10;
      alimentos.splice(i, 1);
      timerAlimentos.splice(i, 1);
      
      if (random() > 0.7) {
        alimentos.push(new Alimento(random(width/2), random(height/2 + 50, height - 30)));
        timerAlimentos.push(floor(random(200, 300)));
      }
    }
  }
  
  // Obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].update();
    obstaculos[i].display();
    
    if (dist(caminhao.x, caminhao.y, obstaculos[i].x, obstaculos[i].y) < 30) {
      gameState = "gameover";
    }
    
    if (obstaculos[i].x < -50) {
      obstaculos.splice(i, 1);
    }
  }
  
  if (frameCount % 30 === 0 && random() > 0.3) {
    let tipo = floor(random(4));
    let yPos = tipo === 3 ? random(50, height/2) : random(height - 150, height - 50);
    obstaculos.push(new Obstaculo(width, yPos, tipo));
  }
  
  // UI
  fill(0);
  textSize(24);
  textAlign(LEFT);
  text(`Pontuação: ${pontuacao}`, 20, 30);
  text(`Fase: ${faseAtual}/${maxFases}`, 20, 60);
  
  if (alimentos.length > 0 && !alimentos[0].coletado) {
    text(`Tempo: ${ceil(timerAlimentos[0]/60)}s`, 20, 90);
  }
  
  // Progressão de fase
  if (pontuacao >= 100 * faseAtual && faseAtual < maxFases) {
    faseAtual++;
    velocidade += 1;
    obstaculos = [];
    
    for (let i = 0; i < faseAtual * 2; i++) {
      obstaculos.push(new Obstaculo(random(width, width + 200), random(50, height - 50), floor(random(4))));
    }
  } else if (pontuacao >= 100 * maxFases) {
    gameState = "vitoria";
  }
}

function telaGameOver() {
  fill(255, 0, 0, 200);
  rect(0, 0, width, height);
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Game Over", width/2, height/2 - 50);
  textSize(24);
  text(`Pontuação: ${pontuacao}`, width/2, height/2 + 20);
  text(`Fase alcançada: ${faseAtual}/${maxFases}`, width/2, height/2 + 50);
  text("Clique para recomeçar", width/2, height/2 + 90);
}

function telaVitoria() {
  fill(0, 100, 0, 200);
  rect(0, 0, width, height);
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("VITÓRIA!", width/2, height/2 - 50);
  textSize(24);
  text(`Pontuação final: ${pontuacao}`, width/2, height/2 + 20);
  text("Você alimentou a cidade inteira!", width/2, height/2 + 50);
  text("Clique para jogar novamente", width/2, height/2 + 90);
}

function mousePressed() {
  if (gameState === "instrucoes") {
    gameState = "jogando";
  } else if (gameState === "gameover" || gameState === "vitoria") {
    resetGame();
  }
}

function resetGame() {
  pontuacao = 0;
  faseAtual = 1;
  velocidade = 3;
  gameState = "jogando";
  caminhao = new Caminhao();
  alimentos = [];
  obstaculos = [];
  timerAlimentos = [];
  
  for (let i = 0; i < 3; i++) {
    alimentos.push(new Alimento(random(width/2), height - 50));
    timerAlimentos.push(floor(random(300, 500)));
  }
}

function keyPressed() {
  if (keyCode === 32 && gameState === "jogando") {
    for (let i = 0; i < alimentos.length; i++) {
      if (!alimentos[i].coletado && dist(caminhao.x, caminhao.y, alimentos[i].x, alimentos[i].y) < 30) {
        alimentos[i].coletado = true;
        break;
      }
    }
  }
}

class Caminhao {
  constructor() {
    this.x = 100;
    this.y = height - 100;
    this.speed = 3;
    this.width = 80;
    this.height = 50;
  }
  
  update() {
    if (gameState !== "jogando") return;
    
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed * 0.9;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed * 0.9;
    if (keyIsDown(UP_ARROW)) this.y -= this.speed * 0.7;
    if (keyIsDown(DOWN_ARROW)) this.y += this.speed * 0.7;
    
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 50, height - 50);
  }
  
  display() {
    fill(255, 100, 0);
    rect(this.x - this.width/2, this.y - this.height/2, this.width, this.height);
    fill(0);
    rect(this.x - this.width/3, this.y - this.height/3, 15, 15);
    rect(this.x + this.width/6, this.y - this.height/3, 15, 15);
  }
}

class Alimento {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.coletado = false;
    this.entregue = false;
    this.tipo = floor(random(3));
  }
  
  update() {
    if (!this.coletado) {
      this.x += random(-3, 3);
      this.x = constrain(this.x, 0, width/2);
    }
  }
  
  display(pisca = false) {
    if (this.entregue) return;
    
    if (pisca) fill(255);
    else if (this.tipo === 0) fill(0, 200, 0);
    else if (this.tipo === 1) fill(200, 0, 0);
    else fill(200, 200, 0);
      
    if (this.tipo === 2) rect(this.x - 10, this.y - 10, 20, 20);
    else ellipse(this.x, this.y, 20, 20);
  }
}

class Obstaculo {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.speed = velocidade + random(0.5);
    this.tipo = tipo;
  }
  
  update() {
    this.x -= this.speed;
    if (this.tipo === 3) this.y += sin(frameCount * 0.1) * 2;
  }
  
  display() {
    switch(this.tipo) {
      case 0: // Vaca
        fill(220);
        ellipse(this.x, this.y, 40, 25);
        fill(0);
        ellipse(this.x - 10, this.y - 5, 5, 5);
        break;
      case 1: // Galinha
        fill(255, 180, 0);
        ellipse(this.x, this.y, 30, 30);
        fill(255, 0, 0);
        triangle(this.x + 15, this.y, this.x + 25, this.y - 5, this.x + 25, this.y + 5);
        break;
      case 2: // Tora
        fill(100, 50, 0);
        rect(this.x - 30, this.y - 15, 60, 30);
        break;
      case 3: // Pássaro
        fill(0, 0, 200);
        ellipse(this.x, this.y, 25, 15);
        triangle(this.x + 12, this.y, this.x + 25, this.y - 5, this.x + 25, this.y + 5);
        break;
    }
  }
}